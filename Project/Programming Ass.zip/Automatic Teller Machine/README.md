# Programming Assignment
## Group Memebers
        Name            Id
1. Yigerem Bisrat       UGR//14
2. Yodahe Gossa         UGR/9595/14
3. Yoak Moges           UGR/3567/14
4. Yohannes Belay       UGR/4223/14

## Question 3
### Assumptions
This code uses 4 files, namely:
#### User File
This file holds the account type, account number, first name, fathers name, password, and sex 
respectively separated by comma.
#### Account File
This file holds the account number and balance respectively separated by comma.
#### Transaction File
This file holds all the transactions taking place.
#### Temporary File
This file holds the account file or user file TEMPORARILY when making:

        Trasnactions
        Deleting user
        Withdraw 
        Deposit


